"use client";

import { useMemo, useState, useTransition } from "react";
import Link from "next/link";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { CreateLinkForm } from "@/components/links/create-link-form";
import LinkActionsMenu from "@/components/links/link-actions-menu";
import {
  MousePointer2,
  CalendarDays,
  CornerDownRight,
  Copy,
  Eye,
  Check,
} from "lucide-react";
import { toast } from "sonner";

const FREE_LINK_LIMIT = 20;

export type LinkListItem = {
  id: string;
  code: string | null;
  shortUrl: string | null;
  targetUrl: string;
  clicks: number | null;
  createdLabel: string;
  isActive: boolean;
  title?: string | null;
};

type LinksListClientProps = {
  links: LinkListItem[];
  workspaceId?: string;
  onToggleActive?: (linkId: string, nextActive: boolean) => void;
};

export function LinksListClient({
  links,
  workspaceId,
  onToggleActive,
}: LinksListClientProps) {
  const [query, setQuery] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "inactive">(
    "all",
  );

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();

    let out = links;

    if (statusFilter === "active") {
      out = out.filter((link) => link.isActive);
    } else if (statusFilter === "inactive") {
      out = out.filter((link) => !link.isActive);
    }

    if (!q) return out;

    return out.filter((link) => {
      const title = (link.title ?? "").toLowerCase();
      return (
        link.targetUrl.toLowerCase().includes(q) ||
        (link.code && link.code.toLowerCase().includes(q)) ||
        (link.shortUrl && link.shortUrl.toLowerCase().includes(q)) ||
        (title && title.includes(q))
      );
    });
  }, [links, query, statusFilter]);

  if (!links) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-40" />
        <Skeleton className="h-20 w-full" />
        <Skeleton className="h-20 w-full" />
      </div>
    );
  }

  const noLinksAtAll = links.length === 0;
  const usedLinks = links.length;
  const remainingLinks = Math.max(FREE_LINK_LIMIT - usedLinks, 0);
  const isAtLimit = usedLinks >= FREE_LINK_LIMIT;

  const handleToggleActive = (linkId: string, nextActive: boolean) => {
    if (onToggleActive) {
      onToggleActive(linkId, nextActive);
      return;
    }

    startTransition(async () => {
      try {
        const res = await fetch(`/api/links/${linkId}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ isActive: nextActive }),
        });

        if (!res.ok) {
          const msg = await res.text().catch(() => "");
          toast.error(msg || "Could not update link");
          return;
        }

        toast.success(nextActive ? "Link enabled" : "Link disabled");
        window.location.reload();
      } catch (err) {
        console.error(err);
        toast.error("Something went wrong updating this link");
      }
    });
  };

  return (
    <div className={cn("wf-dashboard-main space-y-6")}>
      {/* -------------------------------------------------- */}
      {/* HERO HEADER – matches Kompilink banner            */}
      {/* -------------------------------------------------- */}
      <header className="wf-dashboard-header">
        <div className="w-full rounded-[32px] bg-[#006476] px-6 py-6 sm:px-10 sm:py-8">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
            {/* Left: image + title + controls */}
            <div className="flex flex-1 flex-col gap-5 lg:flex-row lg:items-center">
              {/* Stacked image card */}
              <div className="flex justify-start lg:items-center lg:justify-center">
                <div className="relative h-20 w-20 shrink-0 sm:h-24 sm:w-24">
                  <div className="absolute -left-4 top-3 h-16 w-14 rounded-2xl bg-[#F5FF47]" />
                  <div className="relative h-full w-full overflow-hidden rounded-2xl bg-[#FF5A4A]">
                    <img
                      src="/kompi-business.png"
                      alt="Kompi hero"
                      className="h-full w-full object-cover"
                      draggable={false}
                    />
                  </div>
                </div>
              </div>

              <div className="flex-1 space-y-3">
                {/* Title + subtitle */}
                <div className="space-y-1">
                  <p
                    className="text-[32px] sm:text-[40px]"
                    style={{
                      fontFamily: '"Instrument Serif", Georgia, serif',
                      fontWeight: 400,
                      fontStyle: "normal",
                      color: "#F4FBFF",
                    }}
                  >
                    Your links.
                  </p>
                  <p
                    className="text-sm sm:text-base"
                    style={{
                      fontFamily:
                        '"Inter Tight", system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                      color: "rgba(244,251,255,0.9)",
                    }}
                  >
                    Manage short links, track engagement, and jump into analytics.
                  </p>
                </div>

                {/* Filters + search + create button */}
                <div className="mt-3 flex flex-col gap-3 lg:flex-row lg:items-center">
                  {/* Status pill */}
                  <div className="inline-flex w-full max-w-xs items-center rounded-full bg-white p-1 text-sm lg:max-w-[320px]">
                    <button
                      type="button"
                      onClick={() => setStatusFilter("all")}
                      className={cn(
                        "flex-1 rounded-full px-4 py-2 transition",
                        statusFilter === "all"
                          ? "bg-[#006476] text-white"
                          : "text-[#006476]"
                      )}
                    >
                      All
                    </button>
                    <button
                      type="button"
                      onClick={() => setStatusFilter("active")}
                      className={cn(
                        "flex-1 rounded-full px-4 py-2 transition",
                        statusFilter === "active"
                          ? "bg-[#006476] text-white"
                          : "text-[#006476]"
                      )}
                    >
                      Active
                    </button>
                    <button
                      type="button"
                      onClick={() => setStatusFilter("inactive")}
                      className={cn(
                        "flex-1 rounded-full px-4 py-2 transition",
                        statusFilter === "inactive"
                          ? "bg-[#006476] text-white"
                          : "text-[#006476]"
                      )}
                    >
                      Inactive
                    </button>
                  </div>

                  {/* Search + create */}
                  <div className="flex flex-1 flex-col gap-3 sm:flex-row sm:items-center">
                    <Input
                      value={query}
                      onChange={(e) => setQuery(e.target.value)}
                      placeholder="Search by title, URL, code, or short link..."
                      className={cn(
                        "h-11 flex-1 rounded-full border-0 bg-white px-4 text-sm",
                        "text-[#003426] placeholder:text-[rgba(0,0,0,0.4)]",
                        "focus-visible:ring-2 focus-visible:ring-[#00A7C0] focus-visible:ring-offset-0"
                      )}
                      disabled={noLinksAtAll}
                    />

                    <Button
                      asChild
                      disabled={isAtLimit}
                      className="h-11 rounded-full px-6 text-[15px] font-semibold shadow-none disabled:opacity-60"
                      style={{
                        backgroundColor: "#D8FF3B",
                        color: "#003426",
                        fontFamily:
                          '"Inter Tight", system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
                      }}
                    >
                      <Link href="/links/new">Create link</Link>
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: usage text */}
            <div className="mt-2 text-right lg:mt-0">
              <p
                className="text-xs sm:text-sm"
                style={{
                  fontFamily:
                    '"Instrument Serif", Georgia, serif',
                  fontWeight: 400,
                  color: "#F4FBFF",
                }}
              >
                {usedLinks}/{FREE_LINK_LIMIT} links used on the Free plan
                {isAtLimit
                  ? " - delete a link to create more."
                  : " - delete a link to create more."}
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Empty state */}
      {noLinksAtAll ? (
        <section className="wf-dashboard-content flex min-h-[48vh] items-center justify-center">
          <Card className="wf-dashboard-empty-state mx-auto w-full max-w-lg rounded-3xl bg-white px-6 py-8 text-center">
            <h2 className="text-lg font-semibold text-[color:var(--color-text)]">
              Ready to create your first link?
            </h2>
            <p className="mt-1 text-sm text-[color:var(--color-subtle)]">
              Spin up a clean short link and start tracking clicks in seconds.
            </p>

            {workspaceId ? (
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="mt-5 rounded-full px-5 py-2 text-sm font-medium">
                    Create link
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-lg">
                  <DialogHeader>
                    <DialogTitle className="font-semibold">
                      Create a new link
                    </DialogTitle>
                  </DialogHeader>
                  <CreateLinkForm workspaceId={workspaceId} />
                </DialogContent>
              </Dialog>
            ) : null}
          </Card>
        </section>
      ) : (
        // List / Dashboard/ListWithMeta
        <section className="wf-dashboard-content space-y-4">
          {filtered.length === 0 ? (
            <Card className="wf-dashboard-inline-notice rounded-2xl bg-white p-4 text-sm text-[color:var(--color-subtle)]">
              No links found. Try a different search or filter.
            </Card>
          ) : (
            filtered.map((link) => {
              const isCopied = copiedId === link.id;
              const composedShortUrl =
                link.shortUrl ??
                (link.code
                  ? `${
                      typeof window !== "undefined"
                        ? window.location.origin
                        : ""
                    }/r/${link.code}`
                  : "");

              let host: string | null = null;
              try {
                host = new URL(link.targetUrl).hostname;
              } catch {
                host = null;
              }

              const displayTitle =
                link.title?.trim() ||
                (host && link.code
                  ? `${host} – ${link.code}`
                  : host || link.code || "untitled");

              const faviconStyle =
                host != null
                  ? {
                      backgroundImage: `url(https://${host}/favicon.ico)`,
                      backgroundSize: "cover",
                      backgroundPosition: "center",
                    }
                  : undefined;

              return (
                <article
                  key={link.id}
                  className={cn(
                    "wf-dashboard-table-card group rounded-3xl border border-[color:var(--color-border)] bg-white",
                    "transition-colors hover:bg-[color:var(--color-bg)]",
                  )}
                >
                  <div className="flex items-stretch gap-4 px-5 py-4 md:px-6">
                    {/* Left favicon column */}
                    <div className="flex items-center justify-center">
                      <div
                        className="flex h-10 w-10 items-center justify-center rounded-full border border-[color:var(--color-border)] bg-[color:var(--color-bg)]"
                        style={faviconStyle}
                      >
                        {!host && (
                          <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-[color:var(--color-accent)] text-[11px] font-semibold text-[color:var(--color-text)]">
                            →
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Middle content column */}
                    <div className="min-w-0 flex-1 space-y-1.5">
                      <div className="flex flex-wrap items-center gap-2">
                        <h2 className="truncate text-[15px] font-semibold text-[color:var(--color-text)]">
                          {displayTitle}
                        </h2>

                        <span
                          className={cn(
                            "inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-medium tracking-wide border",
                            link.isActive
                              ? "border-[color:var(--color-accent)] bg-[color:var(--color-accent-soft)] text-[color:var(--color-text)]"
                              : "border-[color:var(--color-border)] bg-[color:var(--color-bg)] text-[color:var(--color-subtle)]",
                          )}
                        >
                          {link.isActive ? "ACTIVE" : "INACTIVE"}
                        </span>
                      </div>

                      {composedShortUrl && (
                        <div className="flex flex-wrap items-center gap-2 text-[13px]">
                          <a
                            href={composedShortUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="font-medium text-[color:var(--color-text)] underline decoration-[color:var(--color-accent)] underline-offset-4 hover:decoration-2"
                          >
                            {composedShortUrl}
                          </a>
                        </div>
                      )}

                      <div className="flex items-start gap-1.5 text-[13px] text-[color:var(--color-subtle)]">
                        <CornerDownRight className="mt-[2px] h-[14px] w-[14px] text-[color:var(--color-subtle)] opacity-80" />
                        <span className="truncate">{link.targetUrl}</span>
                      </div>

                      <div className="mt-1.5 flex flex-wrap gap-4 text-[12px] text-[color:var(--color-subtle)]">
                        <span className="inline-flex items-center gap-1">
                          <MousePointer2 className="h-[14px] w-[14px] text-[color:var(--color-subtle)] opacity-80" />
                          <span className="font-medium text-[color:var(--color-text)]">
                            {link.clicks ?? 0}
                          </span>
                          <span className="opacity-80">engagements</span>
                        </span>

                        <span className="inline-flex items-center gap-1">
                          <CalendarDays className="h-[14px] w-[14px] text-[color:var(--color-subtle)] opacity-80" />
                          <span className="opacity-80">
                            {link.createdLabel}
                          </span>
                        </span>
                      </div>
                    </div>

                    {/* Right actions column */}
                    <div className="flex items-center gap-2 pt-1">
                      <button
                        type="button"
                        role="switch"
                        aria-checked={link.isActive}
                        onClick={() => handleToggleActive(link.id, !link.isActive)}
                        disabled={isPending}
                        className={cn(
                          "relative inline-flex h-5 w-9 shrink-0 items-center rounded-full border transition-colors",
                          link.isActive
                            ? "border-transparent bg-[color:var(--color-accent)]"
                            : "border-[color:var(--color-border)] bg-[color:var(--color-bg)]",
                          isPending && "cursor-not-allowed opacity-60",
                        )}
                      >
                        <span
                          className={cn(
                            "inline-block h-4 w-4 rounded-full bg-[color:var(--color-surface)] transition-transform",
                            link.isActive ? "translate-x-4" : "translate-x-1",
                          )}
                        />
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          if (!composedShortUrl) return;
                          if (typeof navigator === "undefined") return;

                          navigator.clipboard
                            .writeText(composedShortUrl)
                            .then(() => {
                              setCopiedId(link.id);
                              setTimeout(() => setCopiedId(null), 1200);
                            })
                            .catch(() => {});
                        }}
                        className={cn(
                          "inline-flex h-8 w-8 items-center justify-center rounded-full border text-[color:var(--color-text)]",
                          "border-[color:var(--color-border)] bg-[color:var(--color-surface)]",
                          "transition-colors hover:bg-[color:var(--color-bg)]",
                        )}
                        aria-label={isCopied ? "Copied" : "Copy short link"}
                      >
                        {isCopied ? (
                          <Check className="h-4 w-4 text-[color:var(--color-accent)]" />
                        ) : (
                          <Copy className="h-4 w-4 text-[color:var(--color-subtle)]" />
                        )}
                      </button>

                      <Link
                        href={`/links/${link.id}`}
                        className={cn(
                          "inline-flex h-8 w-8 items-center justify-center rounded-full border text-[color:var(--color-text)]",
                          "border-[color:var(--color-accent)] bg-[color:var(--color-accent-soft)]",
                          "transition-colors hover:bg-[color:var(--color-accent)]",
                        )}
                        aria-label="View link analytics"
                      >
                        <Eye className="h-4 w-4" />
                      </Link>

                      <LinkActionsMenu
                        id={link.id}
                        shortUrl={composedShortUrl}
                        className={cn(
                          "inline-flex h-8 w-8 items-center justify-center rounded-full border text-[color:var(--color-text)]",
                          "border-[color:var(--color-border)] bg-[color:var(--color-surface)]",
                          "transition-colors hover:bg-[color:var(--color-bg)]",
                        )}
                      />
                    </div>
                  </div>
                </article>
              );
            })
          )}
        </section>
      )}
    </div>
  );
}
