"use client";

import { useState, Suspense, FormEvent } from "react";
import { useSearchParams } from "next/navigation";
import { signIn } from "next-auth/react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";

function SignInForm() {
  const params = useSearchParams();
  const callbackUrl = params.get("callbackUrl") ?? "/links";
  const mode = params.get("mode") ?? "login"; // 'login' or 'signup'
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!email) return;
    setLoading(true);

    try {
      await signIn("credentials", {
        email,
        callbackUrl,
        redirect: true,
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-black via-zinc-950 to-black text-zinc-50">
      <Card className="w-full max-w-md space-y-6 rounded-2xl border border-zinc-800 bg-zinc-950/80 p-6 shadow-xl backdrop-blur">
        <div className="space-y-1 text-center">
          <h1 className="text-xl font-semibold tracking-tight">
            {mode === "signup" ? "Sign up free" : "Log in to Kompi"}
          </h1>
          <p className="text-xs text-zinc-400">
            Use your work or studio email. We’ll create your account if needed.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="email"
            placeholder="you@studio.co"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full rounded-full border border-zinc-800 bg-black/50 px-3 py-2 text-[12px] text-zinc-100 outline-none focus:border-zinc-500"
            required
          />
          <Button
            type="submit"
            disabled={loading}
            className="w-full rounded-full bg-zinc-100 text-[12px] font-semibold text-black hover:bg-white"
          >
            {loading
              ? "Working..."
              : mode === "signup"
              ? "Sign up free"
              : "Log in"}
          </Button>
        </form>

        <div className="text-center text-[11px] text-zinc-500">
          {mode === "signup" ? (
            <p>
              Already have an account?{" "}
              <Link href="/signin?mode=login" className="text-zinc-300 hover:underline">
                Log in
              </Link>
            </p>
          ) : (
            <p>
              New to Kompi?{" "}
              <Link href="/signin?mode=signup" className="text-zinc-300 hover:underline">
                Sign up free
              </Link>
            </p>
          )}
        </div>
      </Card>
    </div>
  );
}

export default function SignInPage() {
  return (
    <Suspense
      fallback={
        <div className="flex min-h-screen items-center justify-center text-xs text-zinc-500">
          Loading sign-in…
        </div>
      }
    >
      <SignInForm />
    </Suspense>
  );
}
