import { getServerSession, type NextAuthOptions } from "next-auth";
import GoogleProvider from "next-auth/providers/google";
import CredentialsProvider from "next-auth/providers/credentials";
import { prisma } from "./prisma";

export const authOptions: NextAuthOptions = {
  providers: [
    // Google (production sign-in)
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID ?? "",
      clientSecret: process.env.GOOGLE_CLIENT_SECRET ?? "",
    }),

    // Dev email (kept for local/testing)
    CredentialsProvider({
      name: "Dev Email",
      credentials: { email: { label: "Email", type: "email" } },
      async authorize(credentials) {
        const raw = credentials?.email;
        const email = typeof raw === "string" ? raw.trim().toLowerCase() : "";
        if (!email) return null;

        let user = await prisma.user.findUnique({ where: { email } });
        if (!user) user = await prisma.user.create({ data: { email } });

        return { id: user.id, email: user.email };
      },
    }),
  ],
  pages: {
    signIn: "/signin",
  },
  session: { strategy: "jwt" },
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        const u = user as any;
        token.id = u.id ?? token.id;
        token.email = u.email ?? token.email;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user = {
          ...session.user,
          id: (token as any).id as string | undefined,
          email: ((token as any).email as string | undefined) ?? session.user.email ?? undefined,
        } as typeof session.user & { id?: string; email?: string | null };
      }
      return session;
    },

    // 🔵 Ensure post-login lands on /dashboard by default
    async redirect({ url, baseUrl }) {
      // If NextAuth gives us a relative path, keep it on our domain
      if (url.startsWith("/")) return `${baseUrl}${url}`;

      // Only allow redirects back to our own origin
      if (url.startsWith(baseUrl)) return url;

      // Fallback target
      return `${baseUrl}/dashboard`;
    },
  },
};

export async function getSession() {
  return getServerSession(authOptions);
}

export async function requireUser() {
  const session = await getServerSession(authOptions);
  let email = session?.user?.email as string | undefined;

  // Dev override so the app doesn't crash when not signed in
  if (!email) {
    if (process.env.NODE_ENV === "development" && process.env.DEV_EMAIL) {
      email = process.env.DEV_EMAIL as string;
    } else {
      throw new Error("Unauthorized");
    }
  }

  let user = await prisma.user.findUnique({ where: { email } });
  if (!user) {
    user = await prisma.user.create({ data: { email } });
  }
  return user;
}

export async function getUserWorkspaces(userId: string) {
  return prisma.workspace.findMany({
    where: { ownerId: userId },
    orderBy: { createdAt: "asc" },
  });
}

export async function getActiveWorkspace(userId: string, workspaceId?: string | null) {
  const workspaces = await getUserWorkspaces(userId);
  if (!workspaces.length) return null;

  if (workspaceId) {
    const byId = workspaces.find((w: any) => w.id === workspaceId);
    if (byId) return byId;
    const bySlug = workspaces.find((w: any) => w.slug === workspaceId);
    if (bySlug) return bySlug;
  }
  return workspaces[0];
}
