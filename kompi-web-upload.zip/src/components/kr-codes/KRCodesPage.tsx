"use client";

import { useMemo, useState } from "react";
import { useForm, SubmitHandler } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import QRCode from "react-qr-code";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

const CreateSchema = z.object({
  destination: z.string().url({ message: "Enter a valid URL" }),
  title: z.string().max(120).optional(),
  createShortLink: z.boolean().default(true),
  domain: z.string().default("kompi.to"),
  backhalf: z.string().max(64).optional(),
  utm_source: z.string().optional(),
  utm_medium: z.string().optional(),
  utm_campaign: z.string().optional(),
  utm_term: z.string().optional(),
  utm_content: z.string().optional(),
});

type CreateForm = z.infer<typeof CreateSchema>;

type Style = {
  fg: string;
  bg: string;
  size: number;
  margin: number;
  logoUrl: string | null;
  cornerRadius: number;
  ecLevel: "L" | "M" | "Q" | "H";
};

const DEFAULTS: CreateForm = {
  destination: "",
  title: undefined,
  createShortLink: true,
  domain: "kompi.to",
  backhalf: undefined,
  utm_source: undefined,
  utm_medium: undefined,
  utm_campaign: undefined,
  utm_term: undefined,
  utm_content: undefined,
};

export default function KRCodesPage() {
  const [step, setStep] = useState<"configure" | "customize">("configure");
  const [createdId, setCreatedId] = useState<string | null>(null);
  const [style, setStyle] = useState<Style>({
    fg: "#22d3ee",
    bg: "transparent",
    size: 240,
    margin: 2,
    logoUrl: null,
    cornerRadius: 0,
    ecLevel: "M",
  });

  const { register, handleSubmit, formState, setValue, watch } =
    useForm<CreateForm>({
      resolver: zodResolver(CreateSchema),
      defaultValues: DEFAULTS,
    });
  const { errors, isSubmitting } = formState;
  const destination = watch("destination");

  const onCreate: SubmitHandler<CreateForm> = async (data) => {
    const payload = {
      destination: data.destination,
      title: data.title,
      createShortLink: data.createShortLink,
      utm: {
        source: data.utm_source,
        medium: data.utm_medium,
        campaign: data.utm_campaign,
        term: data.utm_term,
        content: data.utm_content,
      },
    };

    const res = await fetch("/api/kr-codes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      alert("Failed to create code");
      return;
    }
    const json = await res.json();
    setCreatedId(json.id);
    setStep("customize");
  };

  async function saveStyle() {
    if (!createdId) return;
    await fetch(`/api/kr-codes/${createdId}/style`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(style),
    });
  }

  async function downloadSvg() {
    if (!createdId) return;
    const res = await fetch(`/api/kr-codes/${createdId}/svg`);
    const svg = await res.text();
    const blob = new Blob([svg], { type: "image/svg+xml" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `kompi-code-${createdId}.svg`;
    a.click();
    URL.revokeObjectURL(a.href);
  }

  // Derived URL with UTM preview
  const urlPreview = useMemo(() => {
    try {
      const u = new URL(destination || "https://example.com");
      ["utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content"].forEach(
        (k) => {
          const el = document.querySelector<HTMLInputElement>(`[name=${k}]`);
          const v = el?.value;
          if (v) u.searchParams.set(k, v);
        }
      );
      return u.toString();
    } catch {
      return destination || "";
    }
  }, [destination]);

  return (
    <div className="mx-auto w-full max-w-6xl py-6">
      {/* Header */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Create a new Kompi Code</h1>
          <p className="text-sm text-slate-400">
            Configure code → customize design → download
          </p>
        </div>
        <div className="text-sm text-slate-400">
          {step === "customize" && createdId && (
            <Link
              className="hover:underline"
              href={`/api/kr-codes/${createdId}/svg`}
              target="_blank"
            >
              Open SVG
            </Link>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-6">
        {/* Left: forms */}
        <Card>
          <CardContent className="p-4 md:p-6">
            {/* Step Tabs */}
            <div className="mb-4 flex gap-4 text-sm">
              <button
                className={cn(
                  "px-2 py-1 rounded-md",
                  step === "configure"
                    ? "bg-white/10 text-cyan-300"
                    : "text-slate-300 hover:bg-white/5"
                )}
                onClick={() => setStep("configure")}
              >
                Configure code
              </button>
              <button
                disabled={!createdId}
                className={cn(
                  "px-2 py-1 rounded-md",
                  !createdId
                    ? "opacity-50 cursor-not-allowed"
                    : step === "customize"
                    ? "bg-white/10 text-cyan-300"
                    : "text-slate-300 hover:bg-white/5"
                )}
                onClick={() => setStep("customize")}
              >
                Customize design
              </button>
            </div>

            {step === "configure" ? (
              <form onSubmit={handleSubmit(onCreate)} className="space-y-6">
                {/* Code details */}
                <section className="space-y-3">
                  <h3 className="text-sm font-medium">Code details</h3>
                  <div>
                    <label className="text-xs text-slate-400">
                      Destination URL
                    </label>
                    <Input placeholder="https://…" {...register("destination")} />
                    {errors.destination && (
                      <p className="mt-1 text-xs text-red-300">
                        {errors.destination.message}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="text-xs text-slate-400">
                      Title (optional)
                    </label>
                    <Input
                      placeholder="Spring campaign"
                      {...register("title")}
                    />
                  </div>
                </section>

                {/* Sharing options */}
                <section className="space-y-3">
                  <h3 className="text-sm font-medium">Sharing options</h3>
                  <div className="flex gap-2">
                    <input
                      type="checkbox"
                      defaultChecked
                      onChange={(e) =>
                        setValue("createShortLink", e.target.checked, {
                          shouldDirty: true,
                        })
                      }
                    />
                    <span className="text-sm text-slate-300">
                      Create a short link
                    </span>
                  </div>

                  <div className="grid grid-cols-[160px_1fr] gap-2 items-center">
                    <Select
                      defaultValue="kompi.to"
                      onValueChange={(v) =>
                        setValue("domain", v as any, { shouldDirty: true })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Domain" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="kompi.to">kompi.to</SelectItem>
                        <SelectItem value="kmp.to">kmp.to</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input
                      placeholder="custom-backhalf (optional)"
                      {...register("backhalf")}
                    />
                  </div>
                </section>

                {/* Advanced (UTM) */}
                <section className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-medium">Advanced settings</h3>
                    <span className="text-xs text-slate-400">UTM parameters</span>
                  </div>
                  <div className="grid sm:grid-cols-2 gap-2">
                    <Input
                      placeholder="Source"
                      {...register("utm_source")}
                      name="utm_source"
                    />
                    <Input
                      placeholder="Medium"
                      {...register("utm_medium")}
                      name="utm_medium"
                    />
                    <Input
                      placeholder="Campaign"
                      {...register("utm_campaign")}
                      name="utm_campaign"
                    />
                    <Input
                      placeholder="Term"
                      {...register("utm_term")}
                      name="utm_term"
                    />
                    <Input
                      placeholder="Content"
                      {...register("utm_content")}
                      name="utm_content"
                    />
                  </div>
                  <div className="text-xs text-slate-400">
                    URL preview:{" "}
                    <span className="text-slate-200">{urlPreview || "—"}</span>
                  </div>
                </section>

                <div className="pt-2">
                  <Button disabled={isSubmitting} type="submit">
                    {isSubmitting ? "Creating…" : "Design your code →"}
                  </Button>
                </div>
              </form>
            ) : (
              // Customize step
              <div className="space-y-6">
                <section className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-slate-400">Foreground</label>
                    <Input
                      type="color"
                      value={style.fg}
                      onChange={(e) =>
                        setStyle((s) => ({ ...s, fg: e.target.value }))
                      }
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-400">Background</label>
                    <Input
                      type="color"
                      value={style.bg === "transparent" ? "#000000" : style.bg}
                      onChange={(e) =>
                        setStyle((s) => ({ ...s, bg: e.target.value }))
                      }
                    />
                    <div className="mt-1 text-xs">
                      <button
                        className="underline text-slate-300"
                        onClick={() =>
                          setStyle((s) => ({ ...s, bg: "transparent" }))
                        }
                      >
                        Set transparent
                      </button>
                    </div>
                  </div>
                  <div>
                    <label className="text-xs text-slate-400">Size (px)</label>
                    <Input
                      type="number"
                      min={120}
                      max={1024}
                      value={style.size}
                      onChange={(e) =>
                        setStyle((s) => ({
                          ...s,
                          size: Number(e.target.value),
                        }))
                      }
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-400">Margin</label>
                    <Input
                      type="number"
                      min={0}
                      max={16}
                      value={style.margin}
                      onChange={(e) =>
                        setStyle((s) => ({
                          ...s,
                          margin: Number(e.target.value),
                        }))
                      }
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-400">
                      Corner radius
                    </label>
                    <Input
                      type="number"
                      min={0}
                      max={40}
                      value={style.cornerRadius}
                      onChange={(e) =>
                        setStyle((s) => ({
                          ...s,
                          cornerRadius: Number(e.target.value),
                        }))
                      }
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-400">
                      Error correction
                    </label>
                    <Select
                      value={style.ecLevel}
                      onValueChange={(v) =>
                        setStyle((s) => ({ ...s, ecLevel: v as any }))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="L">L</SelectItem>
                        <SelectItem value="M">M</SelectItem>
                        <SelectItem value="Q">Q</SelectItem>
                        <SelectItem value="H">H</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="sm:col-span-2">
                    <label className="text-xs text-slate-400">
                      Center logo URL (optional)
                    </label>
                    <Input
                      placeholder="https://…/logo.svg"
                      value={style.logoUrl ?? ""}
                      onChange={(e) =>
                        setStyle((s) => ({
                          ...s,
                          logoUrl: e.target.value || null,
                        }))
                      }
                    />
                    <p className="mt-1 text-xs text-slate-400">
                      Tip: use <code>/Kompiwhite.svg</code> for your wordmark.
                    </p>
                  </div>
                </section>

                <div className="flex gap-2">
                  <Button onClick={saveStyle} variant="outline">
                    Save
                  </Button>
                  <Button onClick={downloadSvg}>Download SVG</Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Right: live preview */}
        <Card>
          <CardContent className="p-4 md:p-6">
            <h3 className="mb-4 text-sm font-medium">Preview</h3>
            <div
              className="relative mx-auto"
              style={{ width: style.size, height: style.size }}
            >
              <div
                className={cn(
                  style.bg === "transparent" ? "bg-transparent" : ""
                )}
                style={{
                  width: style.size,
                  height: style.size,
                  padding: style.margin,
                  background:
                    style.bg === "transparent" ? "transparent" : style.bg,
                  borderRadius: style.cornerRadius,
                }}
              >
                <QRCode
                  value={urlPreview || "https://kompi.to"}
                  size={style.size - style.margin * 2}
                  fgColor={style.fg}
                  bgColor="transparent"
                />
              </div>

              {style.logoUrl && (
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <img
                    src={style.logoUrl}
                    alt="logo"
                    style={{
                      width: Math.floor(style.size * 0.24),
                      height: "auto",
                    }}
                  />
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
