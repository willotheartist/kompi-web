"use client";

import { usePathname } from "next/navigation";
import { Navbar } from "@/components/navbar";

const HIDE_PREFIXES = [
  "/dashboard",
  "/links",
  "/p",
  "/features/url-shortener",
  "/signin", // optional: hide on auth page
];

export function NavbarGate() {
  const pathname = usePathname() ?? "/";

  const shouldHide = HIDE_PREFIXES.some((p) => pathname.startsWith(p));
  if (shouldHide) return null;

  return <Navbar />;
}

export default NavbarGate;
