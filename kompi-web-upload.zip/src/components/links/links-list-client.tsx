// src/components/links/links-list-client.tsx
"use client";

import { useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { CreateLinkForm } from "@/components/links/create-link-form";
import LinkActionsMenu from "@/components/links/link-actions-menu";
import { onest } from "@/lib/fonts";
import { MousePointer2, CalendarDays, CornerDownRight } from "lucide-react";

export type LinkListItem = {
  id: string;
  code: string | null;
  shortUrl: string | null;
  targetUrl: string;
  clicks: number | null;
  createdLabel: string;
  isActive: boolean;
};

type LinksListClientProps = {
  links: LinkListItem[];
  /** used for the "Create first link" CTA */
  workspaceId?: string;
};

export function LinksListClient({ links, workspaceId }: LinksListClientProps) {
  const [query, setQuery] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return links;

    return links.filter((link) => {
      return (
        link.targetUrl.toLowerCase().includes(q) ||
        (link.code && link.code.toLowerCase().includes(q)) ||
        (link.shortUrl && link.shortUrl.toLowerCase().includes(q))
      );
    });
  }, [links, query]);

  if (!links) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-40" />
        <Skeleton className="h-20 w-full" />
        <Skeleton className="h-20 w-full" />
      </div>
    );
  }

  const noLinksAtAll = links.length === 0;

  return (
    <div className={cn("space-y-5", onest.className)}>
      {/* Header + search + create */}
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <h1 className="text-[20px] font-semibold text-white/95">Your links</h1>

        <div className="flex w-full flex-col gap-2 sm:flex-row sm:items-center sm:justify-end">
          <Button
            asChild
            className="order-2 h-10 rounded-xl bg-sky-500 px-4 text-[13px] font-semibold text-white shadow-sm hover:bg-sky-600 sm:order-1"
          >
            <a href="/links/new">Create link</a>
          </Button>

          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by URL, code, or short link…"
            className="order-1 w-full max-w-sm rounded-xl bg-white/95 text-slate-900 placeholder:text-slate-400 shadow-sm sm:order-2"
            disabled={noLinksAtAll}
          />
        </div>
      </div>

      {/* Empty state: zero links in workspace */}
      {noLinksAtAll ? (
        <div className="flex min-h-[48vh] items-center justify-center">
          <Card className="mx-auto w-full max-w-lg rounded-3xl border border-slate-200/40 bg-white/95 px-6 py-8 text-center shadow-[0_14px_44px_rgba(15,23,42,0.35)]">
            <h2 className="text-lg font-semibold text-slate-900">
              Ready to create your first link?
            </h2>
            <p className="mt-1 text-sm text-slate-600">
              Spin up a clean short link and start tracking clicks in seconds.
            </p>

            {workspaceId ? (
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="mt-5 rounded-xl bg-slate-900 px-5 py-2 font-medium text-white hover:bg-slate-800">
                    Create link
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-lg">
                  <DialogHeader>
                    <DialogTitle className="font-semibold">
                      Create a new link
                    </DialogTitle>
                  </DialogHeader>
                  <CreateLinkForm workspaceId={workspaceId} />
                </DialogContent>
              </Dialog>
            ) : null}
          </Card>
        </div>
      ) : (
        // List
        <div className="space-y-3">
          {filtered.length === 0 ? (
            <Card className="rounded-2xl border border-slate-200 bg-white p-4 text-sm text-slate-600 shadow-sm">
              No links found. Try a different search.
            </Card>
          ) : (
            filtered.map((link) => {
              const isCopied = copiedId === link.id;
              const composedShortUrl =
                link.shortUrl ??
                (link.code
                  ? `${typeof window !== "undefined" ? window.location.origin : ""}/r/${link.code}`
                  : "");

              let host: string | null = null;
              try {
                host = new URL(link.targetUrl).hostname;
              } catch {
                host = null;
              }

              const title =
                host && link.code
                  ? `${host} – ${link.code}`
                  : host || link.code || "untitled";

              return (
                <article
                  key={link.id}
                  className="rounded-2xl border border-slate-200 bg-white shadow-[0_10px_30px_rgba(15,23,42,0.15)] transition-shadow hover:shadow-[0_18px_48px_rgba(15,23,42,0.24)]"
                >
                  <div className="flex items-stretch gap-4 px-4 py-3 md:px-5">
                    {/* Left selector column */}
                    <div className="flex flex-col items-center gap-3 pt-1">
                      <input
                        type="checkbox"
                        className="h-4 w-4 rounded border-slate-300 text-sky-500 focus:ring-sky-400"
                      />
                      <div className="flex h-8 w-8 items-center justify-center rounded-full border border-slate-200 bg-slate-50">
                        <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-slate-900 text-white text-xs">
                          →
                        </span>
                      </div>
                    </div>

                    {/* Middle content column */}
                    <div className="min-w-0 flex-1 space-y-1.5">
                      {/* Title row */}
                      <div className="flex flex-wrap items-center gap-2">
                        <h2 className="truncate text-[15px] font-semibold text-slate-900">
                          {title}
                        </h2>

                        <span
                          className={cn(
                            "inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-medium tracking-wide",
                            link.isActive
                              ? "bg-sky-50 text-sky-700 ring-1 ring-sky-100"
                              : "bg-slate-50 text-slate-400 ring-1 ring-slate-200"
                          )}
                        >
                          {link.isActive ? "ACTIVE" : "INACTIVE"}
                        </span>
                      </div>

                      {/* Short link */}
                      {composedShortUrl && (
                        <div className="flex flex-wrap items-center gap-2 text-[13px]">
                          <a
                            href={composedShortUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="font-medium text-sky-600 hover:text-sky-700 hover:underline"
                          >
                            {composedShortUrl}
                          </a>
                        </div>
                      )}

                      {/* Long destination */}
                      <div className="flex items-start gap-1.5 text-[13px] text-slate-600">
                        <CornerDownRight className="mt-[2px] h-[14px] w-[14px] opacity-70" />
                        <span className="truncate">{link.targetUrl}</span>
                      </div>

                      {/* Meta row */}
                      <div className="mt-1.5 flex flex-wrap gap-4 text-[12px] text-slate-500">
                        <span className="inline-flex items-center gap-1">
                          <MousePointer2 className="h-[14px] w-[14px] opacity-60" />
                          <span className="font-medium text-slate-700">
                            {link.clicks ?? 0}
                          </span>
                          <span className="opacity-80">engagements</span>
                        </span>

                        <span className="inline-flex items-center gap-1">
                          <CalendarDays className="h-[14px] w-[14px] opacity-60" />
                          <span className="opacity-80">{link.createdLabel}</span>
                        </span>
                      </div>
                    </div>

                    {/* Right actions column */}
                    <div className="flex flex-col items-end gap-2 pt-1 sm:flex-row sm:items-center sm:gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="rounded-full border-slate-300 px-4 text-[13px] text-slate-700 hover:bg-slate-50"
                        onClick={() => {
                          if (!composedShortUrl) return;
                          if (typeof navigator === "undefined") return;

                          navigator.clipboard
                            .writeText(composedShortUrl)
                            .then(() => {
                              setCopiedId(link.id);
                              setTimeout(() => setCopiedId(null), 1500);
                            })
                            .catch(() => {});
                        }}
                      >
                        {isCopied ? "Copied" : "Copy"}
                      </Button>

                      <Button
                        asChild
                        size="sm"
                        variant="outline"
                        className="rounded-full border-slate-300 px-4 text-[13px] text-slate-700 hover:bg-slate-50"
                      >
                        <a href={`/links/${link.id}`}>View</a>
                      </Button>

                      <LinkActionsMenu id={link.id} shortUrl={composedShortUrl} />
                    </div>
                  </div>
                </article>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}
