import { NextResponse } from "next/server";

// Placeholder route for future bio links API.
export async function GET() {
  return NextResponse.json({ message: "Not implemented" }, { status: 501 });
}
