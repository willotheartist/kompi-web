import { NextResponse } from "next/server";
import { z } from "zod";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma"; // <-- named import

const Body = z.object({
  destination: z.string().url(),
  title: z.string().max(120).optional(),
  createShortLink: z.boolean().default(true),
  utm: z.object({
    source: z.string().optional(),
    medium: z.string().optional(),
    campaign: z.string().optional(),
    term: z.string().optional(),
    content: z.string().optional(),
  }).optional(),
});

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string | undefined; // <-- avoid TS error
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const json = await req.json();
  const data = Body.parse(json);

  const url = new URL(data.destination);
  if (data.utm) {
    Object.entries(data.utm).forEach(([k, v]) => { if (v) url.searchParams.set(`utm_${k}`, v); });
  }

  const shortCodeId = null;

  const krc = await prisma.kRCode.create({
    data: {
      destination: url.toString(),
      title: data.title ?? null,
      userId,
      workspaceId: "default",
      shortCodeId,
      style: {
        fg: "#0EA5E9",
        bg: "transparent",
        size: 240,
        margin: 2,
        logoUrl: null,
        cornerRadius: 0,
        ecLevel: "M",
      },
    },
  });

  return NextResponse.json(krc);
}
