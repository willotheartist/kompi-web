import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const Body = z.object({
  fg: z.string().optional(),
  bg: z.string().optional(),
  size: z.number().int().min(120).max(1024).optional(),
  margin: z.number().int().min(0).max(16).optional(),
  logoUrl: z.string().url().nullable().optional(),
  cornerRadius: z.number().int().min(0).max(40).optional(),
  ecLevel: z.enum(["L", "M", "Q", "H"]).optional(),
});

export async function PUT(
  _req: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  const { id } = await context.params;

  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string | undefined;
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = Body.parse(await _req.json());

  const updated = await prisma.kRCode.update({
    where: { id },
    data: { style: { ...(body as any) } },
  });

  return NextResponse.json(updated);
}
