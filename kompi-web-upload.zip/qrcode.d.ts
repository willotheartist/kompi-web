declare module "qrcode";
