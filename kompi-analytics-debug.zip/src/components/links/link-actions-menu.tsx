"use client";

import { useState } from "react";
import Link from "next/link";
import QRCode from "react-qr-code";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import {
  MoreVertical,
  FileText,
  QrCode,
  SquarePlus,
  EyeOff,
  Trash2,
} from "lucide-react";

type Props = {
  id: string;
  shortUrl: string;          // e.g. https://kompi.to/abc123
  className?: string;
};

export default function LinkActionsMenu({ id, shortUrl, className }: Props) {
  const [open, setOpen] = useState(false);       // dropdown
  const [qrOpen, setQrOpen] = useState(false);   // QR dialog

  // simple outside-click close
  function closeOnBlur(e: React.FocusEvent<HTMLDivElement>) {
    if (!e.currentTarget.contains(e.relatedTarget as Node)) setOpen(false);
  }

  async function handleDelete() {
    if (!confirm("Delete this link? This can’t be undone.")) return;
    const res = await fetch(`/api/links/${id}`, { method: "DELETE" });
    if (!res.ok) {
      alert("Failed to delete");
      return;
    }
    // soft refresh
    window.location.reload();
  }

  // (optional) hide link – wire your API if/when available
  async function handleHide() {
    // await fetch(`/api/links/${id}`, { method: "PUT", body: JSON.stringify({ hidden: true }) });
    alert("‘Hide link’ is a placeholder. Wire it to your API when ready.");
  }

  return (
    <>
      <div className={cn("relative", className)} onBlur={closeOnBlur}>
        <Button
          type="button"
          variant="ghost"
          className="h-9 w-9 rounded-xl text-slate-500 hover:text-slate-900 hover:bg-slate-100"
          onClick={() => setOpen((v) => !v)}
          aria-label="More actions"
        >
          <MoreVertical className="h-5 w-5" />
        </Button>

        {open && (
          <div
            tabIndex={-1}
            className="absolute right-0 mt-2 w-56 rounded-xl border border-slate-200 bg-white text-slate-900 shadow-lg focus:outline-none"
          >
            <ul className="py-1 text-sm">
              <li>
                <Link
                  href={`/links/${id}`}
                  className="flex items-center gap-2 px-3 py-2 hover:bg-slate-50"
                  onClick={() => setOpen(false)}
                >
                  <FileText className="h-4 w-4" /> View link details
                </Link>
              </li>
              <li>
                <button
                  className="w-full text-left flex items-center gap-2 px-3 py-2 hover:bg-slate-50"
                  onClick={() => {
                    setOpen(false);
                    setQrOpen(true);
                  }}
                >
                  <QrCode className="h-4 w-4" /> View QR Code
                </button>
              </li>
              <li>
                <Link
                  href={`/bio-pages/new?fromLink=${id}`}
                  className="flex items-center gap-2 px-3 py-2 hover:bg-slate-50"
                  onClick={() => setOpen(false)}
                >
                  <SquarePlus className="h-4 w-4" /> Create Bio Page
                </Link>
              </li>
              <li>
                <button
                  className="w-full text-left flex items-center gap-2 px-3 py-2 hover:bg-slate-50"
                  onClick={handleHide}
                >
                  <EyeOff className="h-4 w-4" /> Hide link
                </button>
              </li>
              <li className="border-t border-slate-200 mt-1 pt-1">
                <button
                  className="w-full text-left flex items-center gap-2 px-3 py-2 text-red-600 hover:bg-red-50"
                  onClick={handleDelete}
                >
                  <Trash2 className="h-4 w-4" /> Delete
                </button>
              </li>
            </ul>
          </div>
        )}
      </div>

      {/* QR modal */}
      <Dialog open={qrOpen} onOpenChange={setQrOpen}>
        <DialogContent className="max-w-sm">
          <div className="flex flex-col items-center gap-4 p-2">
            <QRCode value={shortUrl} size={240} />
            <div className="text-xs text-slate-500 break-all">{shortUrl}</div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
