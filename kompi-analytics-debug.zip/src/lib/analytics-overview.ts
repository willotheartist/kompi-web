// src/lib/analytics-overview.ts
import { prisma } from "@/lib/prisma";
import { endOfDay, startOfDay, subDays } from "date-fns";

export type AnalyticsOverviewData = {
  dateRange: { from: Date; to: Date };
  totalEngagements: number;
  topDate:
    | {
        date: string; // yyyy-MM-dd
        count: number;
      }
    | null;
  timeseries: { date: string; count: number }[];
  byDevice: { device: string; count: number }[];
  byReferrer: { referrer: string; count: number }[];
  byCountry: { country: string; count: number }[];
};

type GetOverviewArgs = {
  workspaceId: string;
  // optional override; otherwise last 7 days
  from?: Date;
  to?: Date;
};

export async function getAnalyticsOverviewForWorkspace({
  workspaceId,
  from,
  to,
}: GetOverviewArgs): Promise<AnalyticsOverviewData> {
  const toDate = endOfDay(to ?? new Date());
  const fromDate = startOfDay(from ?? subDays(toDate, 7));

  /**
   * NOTE: adjust the relations/field names if needed.
   *
   * Assumptions:
   * - Model: ClickEvent
   * - Fields: clickedAt, deviceType, referrer, country
   * - It belongs either to a Link or a KrCode, both of which have workspaceId.
   *   So we OR on link.workspaceId / krCode.workspaceId.
   */
  const events = await prisma.clickEvent.findMany({
    where: {
      clickedAt: {
        gte: fromDate,
        lte: toDate,
      },
      OR: [
        {
          link: {
            workspaceId,
          },
        },
        {
          krCode: {
            workspaceId,
          },
        },
      ],
    },
    select: {
      clickedAt: true,
      deviceType: true,
      referrer: true,
      country: true,
    },
  });

  const totalEngagements = events.length;

  // ---- Timeseries (bucket by day) ----
  const timeseriesMap = new Map<string, number>();

  for (const ev of events) {
    const key = ev.clickedAt.toISOString().slice(0, 10); // yyyy-MM-dd
    timeseriesMap.set(key, (timeseriesMap.get(key) ?? 0) + 1);
  }

  const timeseries = Array.from(timeseriesMap.entries())
    .sort(([a], [b]) => (a < b ? -1 : 1))
    .map(([date, count]) => ({ date, count }));

  const topDate =
    timeseries.length === 0
      ? null
      : timeseries.reduce(
          (top, current) => (current.count > top.count ? current : top),
          timeseries[0]
        );

  // ---- Device breakdown ----
  const deviceMap = new Map<string, number>();
  for (const ev of events) {
    const key = (ev.deviceType ?? "Unknown").toLowerCase();
    deviceMap.set(key, (deviceMap.get(key) ?? 0) + 1);
  }
  const byDevice = Array.from(deviceMap.entries()).map(([device, count]) => ({
    device,
    count,
  }));

  // ---- Referrer breakdown ----
  const referrerMap = new Map<string, number>();
  for (const ev of events) {
    const key = ev.referrer && ev.referrer.trim() !== ""
      ? ev.referrer
      : "Direct / Unknown";
    referrerMap.set(key, (referrerMap.get(key) ?? 0) + 1);
  }
  const byReferrer = Array.from(referrerMap.entries()).map(
    ([referrer, count]) => ({
      referrer,
      count,
    })
  );

  // ---- Country breakdown (top 10) ----
  const countryMap = new Map<string, number>();
  for (const ev of events) {
    const key = ev.country && ev.country.trim() !== ""
      ? ev.country
      : "Unknown";
    countryMap.set(key, (countryMap.get(key) ?? 0) + 1);
  }
  const byCountry = Array.from(countryMap.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([country, count]) => ({ country, count }));

  return {
    dateRange: { from: fromDate, to: toDate },
    totalEngagements,
    topDate,
    timeseries,
    byDevice,
    byReferrer,
    byCountry,
  };
}
