// src/app/dashboard/analytics/page.tsx
import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { getAnalyticsOverview } from "@/lib/analytics";
import { DashboardShell } from "@/components/dashboard/dashboard-shell";
import { AnalyticsOverview } from "@/components/analytics/analytics-overview";

export default async function AnalyticsPage({
  searchParams,
}: {
  searchParams: { workspaceId?: string; from?: string; to?: string };
}) {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect("/signin");
  }

  // however you store the "current" workspace – adapt if you have a helper.
  const workspaceId =
    searchParams.workspaceId || (session.user as any).activeWorkspaceId;

  if (!workspaceId) {
    // fallback to dashboard root or a "no workspace" state
    redirect("/dashboard");
  }

  const from = searchParams.from ? new Date(searchParams.from) : undefined;
  const to = searchParams.to ? new Date(searchParams.to) : undefined;

  const overview = await getAnalyticsOverview({ workspaceId, from, to });

  return (
    <DashboardShell title="Analytics" description="Overview of all activity">
      <AnalyticsOverview data={overview} />
    </DashboardShell>
  );
}
