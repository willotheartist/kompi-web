// src/app/analytics/page.tsx
import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { DashboardShell } from "@/components/dashboard/dashboard-shell";
import { AnalyticsOverview } from "@/components/analytics/analytics-overview";
import { getAnalyticsOverviewForWorkspace } from "@/lib/analytics-overview";

async function getCurrentWorkspaceId(userId: string) {
  // Adjust this if your Workspace/WorkspaceMember schema is different.
  const workspace = await prisma.workspace.findFirst({
    where: {
      ownerId: userId,
    },
    select: { id: true },
  });

  return workspace?.id ?? null;
}

export default async function AnalyticsPage() {
  const session = await getServerSession(authOptions);

  if (!session?.user?.id) {
    redirect("/signin");
  }

  const userId = session.user.id as string;
  const workspaceId = await getCurrentWorkspaceId(userId);

  if (!workspaceId) {
    // No workspace yet – send them back to dashboard or a workspace-setup page
    redirect("/");
  }

  const overview = await getAnalyticsOverviewForWorkspace({ workspaceId });

  return (
    <DashboardShell>
      <AnalyticsOverview data={overview} />
    </DashboardShell>
  );
}
