"use client";

import { useMemo, useState } from "react";
import { useForm, SubmitHandler } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import QRCode from "react-qr-code";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

const CreateSchema = z.object({
  destination: z.string().url({ message: "Enter a valid URL" }),
  title: z.string().max(120).optional(),
  createShortLink: z.boolean().default(true),
  domain: z.string().default("kompi.app"),
  backhalf: z.string().max(64).optional(),
  utm_source: z.string().optional(),
  utm_medium: z.string().optional(),
  utm_campaign: z.string().optional(),
  utm_term: z.string().optional(),
  utm_content: z.string().optional(),
});

type CreateForm = z.infer<typeof CreateSchema>;

type Style = {
  fg: string;
  bg: string;
  size: number;
  margin: number;
  logoUrl: string | null;
  cornerRadius: number;
  ecLevel: "L" | "M" | "Q" | "H";
};

const DEFAULTS: CreateForm = {
  destination: "",
  title: undefined,
  createShortLink: true,
  domain: "kompi.app",
  backhalf: undefined,
  utm_source: undefined,
  utm_medium: undefined,
  utm_campaign: undefined,
  utm_term: undefined,
  utm_content: undefined,
};

export default function KRCodesPage() {
  const [step, setStep] = useState<"configure" | "customize">("configure");
  const [createdId, setCreatedId] = useState<string | null>(null);
  const [style, setStyle] = useState<Style>({
    fg: "#22d3ee",
    bg: "transparent",
    size: 260,
    margin: 4,
    logoUrl: null,
    cornerRadius: 24,
    ecLevel: "M",
  });

  const { register, handleSubmit, formState, setValue, watch } =
    useForm<CreateForm>({
      resolver: zodResolver(CreateSchema),
      defaultValues: DEFAULTS,
    });
  const { errors, isSubmitting } = formState;
  const destination = watch("destination");
  const utm_source = watch("utm_source");
  const utm_medium = watch("utm_medium");
  const utm_campaign = watch("utm_campaign");
  const utm_term = watch("utm_term");
  const utm_content = watch("utm_content");

  const onCreate: SubmitHandler<CreateForm> = async (data) => {
    const payload = {
      destination: data.destination,
      title: data.title,
      createShortLink: data.createShortLink,
      utm: {
        source: data.utm_source,
        medium: data.utm_medium,
        campaign: data.utm_campaign,
        term: data.utm_term,
        content: data.utm_content,
      },
    };

    const res = await fetch("/api/kr-codes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      alert("Failed to create code");
      return;
    }
    const json = await res.json();
    setCreatedId(json.id);
    setStep("customize");
  };

  async function saveStyle() {
    if (!createdId) return;
    await fetch(`/api/kr-codes/${createdId}/style`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(style),
    });
  }

  async function downloadSvg() {
    if (!createdId) return;
    const res = await fetch(`/api/kr-codes/${createdId}/svg`);
    const svg = await res.text();
    const blob = new Blob([svg], { type: "image/svg+xml" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `kompi-code-${createdId}.svg`;
    a.click();
    URL.revokeObjectURL(a.href);
  }

  // Derived URL with UTM preview – fully deterministic between server & client
  const urlPreview = useMemo(() => {
    if (!destination) return "";
    try {
      const u = new URL(destination);
      if (utm_source) u.searchParams.set("utm_source", utm_source);
      if (utm_medium) u.searchParams.set("utm_medium", utm_medium);
      if (utm_campaign) u.searchParams.set("utm_campaign", utm_campaign);
      if (utm_term) u.searchParams.set("utm_term", utm_term);
      if (utm_content) u.searchParams.set("utm_content", utm_content);
      return u.toString();
    } catch {
      // If destination isn't a valid URL yet, just show the raw input
      return destination;
    }
  }, [destination, utm_source, utm_medium, utm_campaign, utm_term, utm_content]);

  return (
    <div className="mx-auto flex w-full max-w-6xl flex-col gap-6 py-6">
      {/* Header */}
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-[22px] font-semibold text-white">
            Kompi Codes™
          </h1>
          <p className="text-sm text-slate-400">
            Turn any URL into a branded, trackable Kompi Code — perfect for
            posters, menus, packaging, and more.
          </p>
        </div>

        <div className="flex flex-col items-end gap-1 text-xs text-slate-400">
          {step === "customize" && createdId && (
            <Link
              className="rounded-full border border-white/10 bg-white/5 px-3 py-1 hover:bg-white/10"
              href={`/api/kr-codes/${createdId}/svg`}
              target="_blank"
            >
              Open SVG in new tab
            </Link>
          )}
          <span className="text-[11px] text-slate-500">
            Configure → Customize → Download
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
        {/* Left: forms */}
        <Card className="border border-white/10 bg-slate-900/70 backdrop-blur-xl shadow-[0_18px_40px_rgba(15,23,42,0.9)]">
          <CardContent className="p-4 md:p-6">
            {/* Step Tabs */}
            <div className="mb-5 inline-flex items-center gap-1 rounded-2xl bg-slate-950/70 p-1 text-xs text-slate-300">
              <button
                type="button"
                className={cn(
                  "inline-flex items-center gap-1 rounded-2xl px-3 py-1 transition",
                  step === "configure"
                    ? "bg-slate-800 text-sky-300 shadow-[0_10px_26px_rgba(56,189,248,0.4)]"
                    : "hover:bg-slate-800/80"
                )}
                onClick={() => setStep("configure")}
              >
                <span className="h-5 w-5 rounded-full bg-sky-500/20 text-center text-[10px] leading-5 text-sky-300">
                  1
                </span>
                Configure
              </button>
              <button
                type="button"
                disabled={!createdId}
                className={cn(
                  "inline-flex items-center gap-1 rounded-2xl px-3 py-1 transition",
                  !createdId
                    ? "opacity-40 cursor-not-allowed"
                    : step === "customize"
                    ? "bg-slate-800 text-sky-300 shadow-[0_10px_26px_rgba(56,189,248,0.4)]"
                    : "hover:bg-slate-800/80"
                )}
                onClick={() => createdId && setStep("customize")}
              >
                <span className="h-5 w-5 rounded-full bg-sky-500/20 text-center text-[10px] leading-5 text-sky-300">
                  2
                </span>
                Customize
              </button>
            </div>

            {step === "configure" ? (
              <form onSubmit={handleSubmit(onCreate)} className="space-y-6">
                {/* Code details */}
                <section className="space-y-3">
                  <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                    Code details
                  </h3>
                  <div>
                    <label className="mb-1 block text-xs text-slate-400">
                      Destination URL
                    </label>
                    <Input
                      placeholder="https://…"
                      {...register("destination")}
                      className="rounded-2xl border-white/10 bg-slate-900 text-slate-50 placeholder:text-slate-500"
                    />
                    {errors.destination && (
                      <p className="mt-1 text-xs text-red-300">
                        {errors.destination.message}
                      </p>
                    )}
                  </div>
                  <div>
                    <label className="mb-1 block text-xs text-slate-400">
                      Title (optional)
                    </label>
                    <Input
                      placeholder="Spring campaign"
                      {...register("title")}
                      className="rounded-2xl border-white/10 bg-slate-900 text-slate-50 placeholder:text-slate-500"
                    />
                  </div>
                </section>

                {/* Sharing options */}
                <section className="space-y-3">
                  <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                    Short link
                  </h3>
                  <div className="flex items-center gap-2 text-sm">
                    <input
                      type="checkbox"
                      defaultChecked
                      onChange={(e) =>
                        setValue("createShortLink", e.target.checked, {
                          shouldDirty: true,
                        })
                      }
                      className="h-4 w-4 rounded border-white/25 bg-slate-900 text-sky-400 focus:ring-sky-500/70"
                    />
                    <span className="text-slate-200">
                      Create a short link alongside your Kompi Code
                    </span>
                  </div>

                  <div className="grid items-center gap-2 sm:grid-cols-[160px_minmax(0,1fr)]">
                    <Select
                      defaultValue="kompi.app"
                      onValueChange={(v) =>
                        setValue("domain", v as any, { shouldDirty: true })
                      }
                    >
                      <SelectTrigger className="rounded-2xl border-white/10 bg-slate-900 text-slate-50">
                        <SelectValue placeholder="Domain" />
                      </SelectTrigger>
                      <SelectContent className="border-white/10 bg-slate-900 text-slate-50">
                        <SelectItem value="kompi.app">kompi.app</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input
                      placeholder="custom-backhalf (optional)"
                      {...register("backhalf")}
                      className="rounded-2xl border-white/10 bg-slate-900 text-slate-50 placeholder:text-slate-500"
                    />
                  </div>
                </section>

                {/* Advanced (UTM) */}
                <section className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                      Advanced settings
                    </h3>
                    <span className="text-[11px] text-slate-500">
                      Optional UTM parameters
                    </span>
                  </div>
                  <div className="grid gap-2 sm:grid-cols-2">
                    <Input
                      placeholder="Source"
                      {...register("utm_source")}
                      name="utm_source"
                      className="rounded-2xl border-white/10 bg-slate-900 text-slate-50 placeholder:text-slate-500"
                    />
                    <Input
                      placeholder="Medium"
                      {...register("utm_medium")}
                      name="utm_medium"
                      className="rounded-2xl border-white/10 bg-slate-900 text-slate-50 placeholder:text-slate-500"
                    />
                    <Input
                      placeholder="Campaign"
                      {...register("utm_campaign")}
                      name="utm_campaign"
                      className="rounded-2xl border-white/10 bg-slate-900 text-slate-50 placeholder:text-slate-500"
                    />
                    <Input
                      placeholder="Term"
                      {...register("utm_term")}
                      name="utm_term"
                      className="rounded-2xl border-white/10 bg-slate-900 text-slate-50 placeholder:text-slate-500"
                    />
                    <Input
                      placeholder="Content"
                      {...register("utm_content")}
                      name="utm_content"
                      className="rounded-2xl border-white/10 bg-slate-900 text-slate-50 placeholder:text-slate-500"
                    />
                  </div>
                  <div className="text-xs text-slate-400">
                    URL preview:{" "}
                    <span className="text-slate-100">
                      {urlPreview || "—"}
                    </span>
                  </div>
                </section>

                <div className="pt-3">
                  <Button
                    disabled={isSubmitting}
                    type="submit"
                    className="rounded-2xl bg-gradient-to-r from-sky-500 via-blue-500 to-cyan-400 px-5 text-sm font-semibold text-white shadow-[0_14px_40px_rgba(56,189,248,0.8)] hover:brightness-110"
                  >
                    {isSubmitting ? "Creating…" : "Create & customize →"}
                  </Button>
                </div>
              </form>
            ) : (
              // Customize step
              <div className="space-y-6">
                <section className="space-y-4">
                  <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                    Visual style
                  </h3>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div>
                      <label className="mb-1 block text-xs text-slate-400">
                        Foreground color
                      </label>
                      <Input
                        type="color"
                        value={style.fg}
                        onChange={(e) =>
                          setStyle((s) => ({ ...s, fg: e.target.value }))
                        }
                        className="h-9 cursor-pointer rounded-2xl border-white/10 bg-slate-900"
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-xs text-slate-400">
                        Background
                      </label>
                      <Input
                        type="color"
                        value={style.bg === "transparent" ? "#000000" : style.bg}
                        onChange={(e) =>
                          setStyle((s) => ({ ...s, bg: e.target.value }))
                        }
                        className="h-9 cursor-pointer rounded-2xl border-white/10 bg-slate-900"
                      />
                      <button
                        type="button"
                        className="mt-1 text-[11px] text-sky-300 hover:underline"
                        onClick={() =>
                          setStyle((s) => ({ ...s, bg: "transparent" }))
                        }
                      >
                        Set transparent background
                      </button>
                    </div>
                    <div>
                      <label className="mb-1 block text-xs text-slate-400">
                        Size (px)
                      </label>
                      <Input
                        type="number"
                        min={120}
                        max={1024}
                        value={style.size}
                        onChange={(e) =>
                          setStyle((s) => ({
                            ...s,
                            size: Number(e.target.value),
                          }))
                        }
                        className="rounded-2xl border-white/10 bg-slate-900 text-slate-50"
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-xs text-slate-400">
                        Margin
                      </label>
                      <Input
                        type="number"
                        min={0}
                        max={16}
                        value={style.margin}
                        onChange={(e) =>
                          setStyle((s) => ({
                            ...s,
                            margin: Number(e.target.value),
                          }))
                        }
                        className="rounded-2xl border-white/10 bg-slate-900 text-slate-50"
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-xs text-slate-400">
                        Corner radius
                      </label>
                      <Input
                        type="number"
                        min={0}
                        max={64}
                        value={style.cornerRadius}
                        onChange={(e) =>
                          setStyle((s) => ({
                            ...s,
                            cornerRadius: Number(e.target.value),
                          }))
                        }
                        className="rounded-2xl border-white/10 bg-slate-900 text-slate-50"
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-xs text-slate-400">
                        Error correction
                      </label>
                      <Select
                        value={style.ecLevel}
                        onValueChange={(v) =>
                          setStyle((s) => ({ ...s, ecLevel: v as any }))
                        }
                      >
                        <SelectTrigger className="rounded-2xl border-white/10 bg-slate-900 text-slate-50">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="border-white/10 bg-slate-900 text-slate-50">
                          <SelectItem value="L">L (low)</SelectItem>
                          <SelectItem value="M">M (medium)</SelectItem>
                          <SelectItem value="Q">Q (quartile)</SelectItem>
                          <SelectItem value="H">H (high)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="sm:col-span-2">
                      <label className="mb-1 block text-xs text-slate-400">
                        Center logo URL (optional)
                      </label>
                      <Input
                        placeholder="https://…/logo.svg"
                        value={style.logoUrl ?? ""}
                        onChange={(e) =>
                          setStyle((s) => ({
                            ...s,
                            logoUrl: e.target.value || null,
                          }))
                        }
                        className="rounded-2xl border-white/10 bg-slate-900 text-slate-50 placeholder:text-slate-500"
                      />
                      <p className="mt-1 text-[11px] text-slate-500">
                        Tip: use <code className="text-slate-300">/Kompiwhite.svg</code>{" "}
                        for a clean Kompi wordmark in the center.
                      </p>
                    </div>
                  </div>
                </section>

                <div className="flex flex-wrap gap-2 pt-1">
                  <Button
                    onClick={saveStyle}
                    variant="outline"
                    className="rounded-2xl border-white/20 bg-slate-900/80 text-slate-100 hover:border-sky-500/70 hover:bg-slate-900"
                  >
                    Save style
                  </Button>
                  <Button
                    onClick={downloadSvg}
                    className="rounded-2xl bg-gradient-to-r from-sky-500 via-blue-500 to-cyan-400 px-5 text-sm font-semibold text-white shadow-[0_14px_40px_rgba(56,189,248,0.8)] hover:brightness-110"
                  >
                    Download SVG
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Right: live preview */}
        <Card className="border border-white/10 bg-slate-900/70 backdrop-blur-xl shadow-[0_18px_40px_rgba(15,23,42,0.9)]">
          <CardContent className="flex h-full flex-col justify-between p-4 md:p-6">
            <div>
              <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                Live preview
              </h3>
              <p className="mt-1 text-xs text-slate-500">
                Scan-ready Kompi Code based on your destination URL and UTM
                parameters.
              </p>
            </div>
            <div className="mt-6 flex flex-1 items-center justify-center">
              <div
                className="relative rounded-[32px] bg-gradient-to-br from-sky-500/20 via-cyan-400/10 to-transparent p-4 shadow-[0_24px_70px_rgba(15,23,42,1)]"
              >
                <div
                  className="relative flex items-center justify-center rounded-[24px] bg-slate-950/90 p-4"
                  style={{
                    width: style.size,
                    height: style.size,
                  }}
                >
                  <div
                    className={cn(
                      style.bg === "transparent" ? "bg-transparent" : ""
                    )}
                    style={{
                      width: style.size,
                      height: style.size,
                      padding: style.margin,
                      background:
                        style.bg === "transparent" ? "transparent" : style.bg,
                      borderRadius: style.cornerRadius,
                    }}
                  >
                    <QRCode
                      value={urlPreview || "https://kompi.app"}
                      size={style.size - style.margin * 2}
                      fgColor={style.fg}
                      bgColor="transparent"
                    />
                  </div>

                  {style.logoUrl && (
                    <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                      <img
                        src={style.logoUrl}
                        alt="logo"
                        style={{
                          width: Math.floor(style.size * 0.24),
                          height: "auto",
                        }}
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="mt-4 text-[11px] text-slate-500">
              Destination preview:{" "}
              <span className="break-all text-slate-200">
                {urlPreview || "—"}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
