import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireUser, getActiveWorkspace } from "@/lib/auth";

const APP_URL =
  process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";

const FREE_QR_LIMIT = 20;




const CREATOR_QR_LIMIT = 100;

const BodySchema = z.object({
  destination: z.string().min(1),
  title: z.string().max(120).optional(),
  createShortLink: z.boolean().optional().default(true),
  // content type of the QR (website, file, app, social, other, etc.)
  type: z.string().optional(),
  utm: z
    .object({
      source: z.string().optional(),
      medium: z.string().optional(),
      campaign: z.string().optional(),
      term: z.string().optional(),
      content: z.string().optional(),
    })
    .optional(),
  style: z
    .object({
      fg: z.string().optional(),
      bg: z.string().optional(),
      size: z.number().int().min(120).max(1024).optional(),
      margin: z.number().int().min(0).max(16).optional(),
      logoUrl: z.string().nullable().optional(),
      cornerRadius: z.number().int().min(0).max(40).optional(),
      ecLevel: z.enum(["L", "M", "Q", "H"]).optional(),
    })
    .optional(),
});

const DEFAULT_STYLE = {
  fg: "#0EA5E9",
  bg: "transparent",
  size: 240,
  margin: 2,
  logoUrl: null as string | null,
  cornerRadius: 0,
  ecLevel: "M" as const,
};

function generateCode(len = 6) {
  const chars =
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let out = "";
  for (let i = 0; i < len; i++) {
    out += chars[Math.floor(Math.random() * chars.length)];
  }
  return out;
}

type KRCodeRecord = Awaited<
  ReturnType<typeof prisma.kRCode.findMany>
>[number];

export async function GET(req: Request) {
  try {
    const user = await requireUser();
    const { searchParams } = new URL(req.url);
    const workspaceId = searchParams.get("workspaceId");

    const workspace = await getActiveWorkspace(user.id, workspaceId);
    if (!workspace) {
      return NextResponse.json({ workspace: null, codes: [] });
    }

    const codes = await prisma.kRCode.findMany({
      where: { workspaceId: workspace.id },
      orderBy: { createdAt: "desc" },
    });

    const linkIds = codes
      .map((c) => c.shortCodeId)
      .filter((id): id is string => Boolean(id));

    const events =
      linkIds.length === 0
        ? []
        : await prisma.clickEvent.groupBy({
            by: ["linkId"],
            where: { linkId: { in: linkIds } },
            _count: { _all: true },
          });

    const scansByLinkId = new Map<string, number>(
      events.map((e) => [e.linkId, e._count._all]),
    );

    const enriched: Array<KRCodeRecord & { totalClicks: number }> =
      codes.map((c) => ({
        ...c,
        totalClicks: c.shortCodeId
          ? scansByLinkId.get(c.shortCodeId) ?? 0
          : 0,
      }));

    return NextResponse.json({ workspace, codes: enriched });
  } catch (err) {
    console.error("GET /api/kr-codes error", err);
    return new NextResponse("Unauthorized", { status: 401 });
  }
}

export async function POST(req: Request) {
  try {
    const user = await requireUser();

    const rawBody = await req.json().catch(() => ({}));
    const body = BodySchema.parse(rawBody);

    // Try to treat destination as URL for UTMs; fall back if it's not valid
    const finalUrl = (() => {
      try {
        const u = new URL(body.destination);
        if (body.utm?.source)
          u.searchParams.set("utm_source", body.utm.source);
        if (body.utm?.medium)
          u.searchParams.set("utm_medium", body.utm.medium);
        if (body.utm?.campaign)
          u.searchParams.set("utm_campaign", body.utm.campaign);
        if (body.utm?.term)
          u.searchParams.set("utm_term", body.utm.term);
        if (body.utm?.content)
          u.searchParams.set("utm_content", body.utm.content);
        return u.toString();
      } catch {
        return body.destination;
      }
    })();

    const { searchParams } = new URL(req.url);
    const workspaceIdFromQuery = searchParams.get("workspaceId");

    const workspace =
      (await getActiveWorkspace(user.id, workspaceIdFromQuery)) ??
      (await prisma.workspace.create({
        data: {
          name: "My workspace",
          slug: `ws-${user.id.slice(0, 6)}`,
          ownerId: user.id,
        },
      }));

    // --- plan-based KR / QR limits ---
    const qrLimit =
      workspace.plan === "CREATOR" ? CREATOR_QR_LIMIT : FREE_QR_LIMIT;

    const qrCount = await prisma.kRCode.count({
      where: { workspaceId: workspace.id },
    });

    if (qrCount >= qrLimit) {
      const isCreator = workspace.plan === "CREATOR";
      const prefix = isCreator ? "Creator plan limit" : "Free plan limit";

      return new NextResponse(
        `${prefix} reached: you can create up to ${qrLimit} KR / QR codes in this workspace.`,
        { status: 402 },
      );
    }
    // ----------------------------------

    let shortLinkId: string | null = null;
    let qrDestination = finalUrl;

    if (body.createShortLink) {
      let code: string;
      while (true) {
        const candidate = generateCode();
        const exists = await prisma.link.findFirst({
          where: { code: candidate },
        });
        if (!exists) {
          code = candidate;
          break;
        }
      }

      const link = await prisma.link.create({
        data: {
          workspaceId: workspace.id,
          code,
          targetUrl: finalUrl,
          isActive: true,
        },
      });

      shortLinkId = link.id;
      qrDestination = `${APP_URL}/r/${link.code}`;
    }

    const krc = await prisma.kRCode.create({
      data: {
        workspaceId: workspace.id,
        userId: user.id,
        title: body.title ?? null,
        destination: qrDestination,
        shortCodeId: shortLinkId,
        type: body.type ?? null,
        style: {
          ...DEFAULT_STYLE,
          ...(body.style ?? {}),
        },
      },
    });

    return NextResponse.json(krc, { status: 201 });
  } catch (err) {
    console.error("POST /api/kr-codes error", err);
    return new NextResponse("Bad Request", { status: 400 });
  }
}