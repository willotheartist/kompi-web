import { ProfileSettingsClient } from "@/components/settings/profile-settings-client";

export default function DashboardProfileSettingsPage() {
  return <ProfileSettingsClient />;
}
