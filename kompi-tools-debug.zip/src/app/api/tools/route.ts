import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireUser, getActiveWorkspace } from "@/lib/auth";

// GET /api/tools
// Returns enabled toolIds for the active workspace.
export async function GET(req: Request) {
  try {
    const user = await requireUser();
    const { searchParams } = new URL(req.url);
    const workspaceId = searchParams.get("workspaceId");

    const workspace = await getActiveWorkspace(user.id, workspaceId);
    if (!workspace) {
      return NextResponse.json({ workspace: null, toolIds: [] });
    }

    let tools = await prisma.workspaceTool.findMany({
      where: { workspaceId: workspace.id, enabled: true },
      orderBy: { createdAt: "asc" },
    });

    // Seed password-generator as the first tool if none exist yet
    if (tools.length === 0) {
      const seeded = await prisma.workspaceTool.create({
        data: {
          workspaceId: workspace.id,
          toolId: "password-generator",
          enabled: true,
        },
      });
      tools = [seeded];
    }

    const toolIds = tools.map((t) => t.toolId);
    return NextResponse.json({ workspace, toolIds });
  } catch (error) {
    console.error("TOOLS_GET_ERROR", error);
    return new NextResponse("Unauthorized", { status: 401 });
  }
}
